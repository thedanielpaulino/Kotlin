package com.example.restaurante

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.restaurante.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() { // Declara o MainActivity

    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater) //inicia o layout inflater

        super.onCreate(savedInstanceState)
        setContentView(binding.root)


        val username = intent.extras?.getString("username")

        if(!username.isNullOrEmpty()){
            binding.textOla.setText("Olá $username") // Define o texto que dá um "oi" para o usuario que fez o login
        }

        binding.buttonFechar.setOnClickListener {
            finishAffinity()
        }

        binding.buttonPedir.setOnClickListener {
            val i = Intent(this, SplashActivity::class.java)
            i.putExtra("quantidadePizza", binding.editQuantidadePizza.toString())
            i.putExtra("quantidadeSalada", binding.editQuantidadeSalada.toString())
            i.putExtra("quantidadeHamburguer", binding.editQuantidadeHamburguer.toString())
            //define a quantidade das comidas como extra na intenção
            startActivity(i)
            finish()
        }


        binding.checkPizza.setOnClickListener { // Define um listener de clique para checkPizza
            if (binding.checkPizza.isChecked()) { // Verifica se o checkPizza está marcado
                binding.editQuantidadePizza.setText("1") // Define a quantidade de pizza como 1
                binding.textPrecoPizza.visibility = View.VISIBLE // Torna o texto de preço da pizza visível
            } else { // Se o checkPizza não estiver marcado
                binding.editQuantidadePizza.setText("0") // Define a quantidade de pizza como 0
                binding.textPrecoPizza.visibility = View.GONE // Torna o texto de preço da pizza invisível
            }
        }
            // todos os códigos têm o mesma função
        binding.checkSalada.setOnClickListener {
            if(binding.checkSalada.isChecked()){
                binding.editQuantidadeSalada.setText("1")
                binding.textPrecoSalada.visibility = View.VISIBLE
            }else{
                binding.editQuantidadeSalada.setText("0")
                binding.textPrecoSalada.visibility = View.GONE
            }
        }

        binding.checkHamburger.setOnClickListener {
            if(binding.checkHamburger.isChecked()){
                binding.editQuantidadeHamburguer.setText("1")
                binding.textPrecoHamburguer.visibility = View.VISIBLE
            }else{
                binding.editQuantidadeHamburguer.setText("0")
                binding.textPrecoHamburguer.visibility = View.GONE
            }
        }

    }
}