package com.example.restaurante

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) { // Sobrescreve o método onCreate
        super.onCreate(savedInstanceState) // Chama a implementação do método onCreate da classe mãe
        setContentView(R.layout.activity_splash) // Define o layout da atividade como activity_splash

        Handler(Looper.getMainLooper()).postDelayed({ // executa uma tarefa após um atraso de 2000 milissegundos
            val i = intent
            val j = Intent(this, PedidoActivity::class.java)
            j.putExtras(i) // Transfere os extras da intenção atual para a nova intenção
            startActivity(j) // Inicia a atividade PedidoActivity
        }, 2000) //
    }
}
